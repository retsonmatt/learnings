<?php

	header('Location: view/auth/login.php');


?>